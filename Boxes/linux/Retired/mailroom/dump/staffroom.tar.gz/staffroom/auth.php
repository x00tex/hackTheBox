<?php
require 'vendor/autoload.php';

session_start(); // Start a session
// $client = new MongoDB\Client("mongodb://mongodb:27017"); // Connect to the MongoDB database
$client = new MongoDB\Client("mongodb://172.17.0.2:27017"); /* MODIFIED */
header('Content-Type: application/json');
if (!$client) {
  header('HTTP/1.1 503 Service Unavailable');
  echo json_encode(['success' => false, 'message' => 'Failed to connect to the database']);
  exit;
}

/* MODIFIED */

// Create the backend_panel database and users collection if they don't exist
$database = $client->backend_panel;
$collection = $database->users;
$collection->createIndex(['email' => 1], ['unique' => true]); // Ensure email is unique

// Define the user document structure
$user_document = [
  'email' => '',
  'password' => '',
  '2fa_token' => '',
  'token_creation' => ''
];

// Check if the users collection is empty and add a test user
$user_count = $collection->countDocuments([]);
if ($user_count === 0) {
  $user_document['email'] = 'tristan@mailroom.htb';
  $user_document['password'] = '69trisRulez!';
  $collection->insertOne($user_document);
}

// $collection = $client->backend_panel->users; // Select the users collection

/* MODIFIED */

// Authenticate user & Send 2FA if valid
if (isset($_POST['email']) && isset($_POST['password'])) {

  // Verify the parameters are valid
  if (!is_string($_POST['email']) || !is_string($_POST['password'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'message' => 'Invalid input detected']);
    // exit; /* MODIFIED :BUG:*/
  }

  // Check if the email and password are correct
  $user = $collection->findOne(['email' => $_POST['email'], 'password' => $_POST['password']]);

  if ($user) {
    // Generate a random UUID for the 2FA token
    $token = bin2hex(random_bytes(16));
    $now = time();

    // Update the user record in the database with the 2FA token if not already sent in the last minute
    $user = $collection->findOne(['_id' => $user['_id']]);
    if(($user['2fa_token'] && ($now - $user['token_creation']) > 60) || !$user['2fa_token']) {
        $collection->updateOne(
          ['_id' => $user['_id']],
          ['$set' => ['2fa_token' => $token, 'token_creation' => $now]]
        );

        // Send an email to the user with the 2FA token
        $to = $user['email'];
        $subject = '2FA Token';
        $message = 'Click on this link to authenticate: http://staff-review-panel.mailroom.htb/auth.php?token=' . $token;
        mail($to, $subject, $message);
    }
    // Return a JSON response notifying about 2fa
    echo json_encode(['success' => true, 'message' => 'Check your inbox for an email with your 2FA token']);
    exit;

  } else {
    // Return a JSON error response
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
  }
}

// Check for invalid parameters
else if (!isset($_GET['token'])) {
  header('HTTP/1.1 400 Bad Request');
  echo json_encode(['success' => false, 'message' => 'Email and password are required']);
  exit;
}

// Check if the form has been submitted
else if (isset($_GET['token'])) {
  // Verify Token parameter is valid
  if (!is_string($_GET['token']) || strlen($_GET['token']) !== 32) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'message' => 'Invalid input detected']);
    exit;
  }

  // Check if the token is correct
  $user = $collection->findOne(['2fa_token' => $_GET['token']]);

  if ($user) {
    // Set the logged_in flag and name in the session
    $_SESSION['logged_in'] = true;
    $_SESSION['name'] = explode('@', $user['email'])[0];

    // Remove 2FA token since user already used it to log in
    $collection->updateOne(
      ['_id' => $user['_id']],
      ['$unset' => ['2fa_token' => '']]
    );

    // Redirect to dashboard since login was successful
    header('Location: dashboard.php');
    exit;
  } else {
    // Return a JSON error response
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'message' => 'Invalid 2FA Login Token']);
    exit;
  }
}


?>
